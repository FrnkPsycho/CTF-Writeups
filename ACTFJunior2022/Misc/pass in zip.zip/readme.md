# misc

学弟学妹们，国庆快乐！

如果对misc感兴趣，建议在buuoj上多练习，多看wp，积累经验和工具！

misc对ctf是很好的加分项。

